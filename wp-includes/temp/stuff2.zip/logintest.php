<?php wp_set_current_user( $id ); ?>
